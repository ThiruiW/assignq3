test_that("Multiserver handles multiple servers correctly", {
  Arrivals <- c(1, 2, 3)
  ServiceTimes <- c(4, 5, 6)
  result <- Multiserver(Arrivals, ServiceTimes, 2)

  expect_equal(nrow(result), 3)
  expect_true(all(result$ServiceBegins >= Arrivals))
})

test_that("Multiserver stops with negative values", {
  expect_error(Multiserver(Arrivals = c(1, -2, 3), ServiceTimes = c(1, 2, 1), NumServers = 2))
})

